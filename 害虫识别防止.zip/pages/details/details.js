// pages/one/one.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        sections:[
            {'id':"info",'section':'简介'}
        ]
    },
    scrollToSection(sectionId) {
        var section = document.getElementById(sectionId);
        section.scrollIntoView();
      },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        const that = this
        wx.showLoading({
            title: '识别中',
            mask: true 
        })
        setTimeout(function () {
            wx.hideLoading()
          }, 200)
        console.log(options.index)
        //当用户识别访问一次后退出再次进入该页面时，没必要再次发送请求
        if(that.data.result)
            console.log(that.result.no)
        if(that.data.result && options.index == that.data.result.no){
            console.log('没有发送')
            return
        }
        else{
            console.log('发送了post')
            wx.request({
                url: 'http://123.57.11.96:5000/pest',
                method: 'POST',
                header: {
                'content-type': 'application/json' // 以JSON格式发送请求
                },
                data: {
                no: options.index // 将base64编码的图片数据作为请求体
                },
            success: function (res) {
                that.setData({
                    result:res.data
                })
                // 处理返回结果
                },
            fail: function (res) {
                console.log(res)
                }
            })
        }
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {
    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
        // let newList = []
        // for (let i = 1; i <= 5; i++) {
        //   newList.push(this.data.pageList[this.data.pageList.length-1] + i)
        // }
        // this.setData({
        //   pageList: [...this.data.pageList, ...newList]
        // })
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})