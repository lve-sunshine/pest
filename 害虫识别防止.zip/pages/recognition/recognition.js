// pages/hello/hello.js
Page({

    /**
     * 页面的初始数据
     */   
    data: {
        classes_names:["黄足黄守瓜", "烟粉虱",
                 "稻赤斑沫蝉", "角蜡蚧",
                 "油菜茎象甲", "豆突眼长蝽",
                 "二化螟", "豌豆彩潜蝇",
                 "大青叶蝉", "稻棘缘蝽",
                 "悬铃木方翅网蝽", "菊方翅网蝽",
                 "稻铁甲", "红袖蜡蝉",
                 "小麦叶蜂", "斑须蝽",
                 "栗瘿蜂", "小绿叶蝉",
                 "菜蝽", "赤条蝽",
                 "茶翅蝽", "乌桕癞皮瘤蛾",
                 "灰飞虱", "大稻缘蝽",
                 "葱黄寡毛跳甲", "斑衣蜡蝉",
                 "豆荚野螟", "稻绿蝽",
                 "褐飞虱", "黄曲条跳甲",
                 "菜粉蝶", "小菜蛾",
                 "台湾黄毒蛾", "点蜂缘蝽",
                 "稻黑蝽", "大螟",
                 "尘污灯蛾", "斜纹夜蛾",
                 "广二星蝽", "油菜叶露尾甲"
                 ] 
    },

    chooseToSub(){
        const that = this
        wx.chooseMedia({
            count: 1,
            mediaType: ['image'],
            sourceType: ['album', 'camera'],
            camera: 'back',
            success(res) {
              console.log(res.tempFiles[0].tempFilePath)
              console.log(res.tempFiles[0].size)
              that.setData({
                  tempPhoto:res.tempFiles[0].tempFilePath
                }
              )
            }
          })
    },   
    toSub(){
        const that = this
        if(that.data.tempPhoto){
            // 故意卡一会
            // 带商酌。。。。。？？？？？？？？。
            wx.showLoading({
                title: '识别中',
                mask: true 
            })
            setTimeout(function () {
                wx.hideLoading()
              }, 200)
            wx.getFileSystemManager().readFile({
                filePath: that.data.tempPhoto,
                encoding: 'base64',
            success: function (res) {
                let base64Data = res.data;
                // 发送请求到后端API
                wx.request({
                    url: 'http://123.57.11.96:5000/inference',
                    method: 'POST',
                    header: {
                    'content-type': 'application/json' // 以JSON格式发送请求
                    },
                    data: {
                    image_data: base64Data // 将base64编码的图片数据作为请求体
                    },
                success: function (res) {
                    console.log(res.data);
                    that.setData({
                        result:res.data
                    })
                    console.log(that.data.result)
                    // 处理返回结果
                    },
                fail: function (res) {
                    console.log(res)
                    }
            })
        }})
    }
    else{
            wx.showToast({
                title: '尚未上传图片',
                icon: 'error',
                duration: 2000
              })
        }

    },

    toShowDetails(){
        wx.navigateTo({
          url: '../details/details?index='+this.data.result.class
        })
    },
    

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})